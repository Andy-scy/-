import re

def parse_command(command):
    result = {
        "action": None,
        "object": None,
        "color": None,
        "target": None
    }

    if "拿" in command or "抓" in command:
        result["action"] = "pick"
    elif "放" in command:
        result["action"] = "place"

    colors = ["红色", "蓝色", "绿色"]
    for color in colors:
        if color in command:
            result["color"] = color

    if "物体" in command or "东西" in command:
        result["object"] = "object"

    if "左边" in command:
        result["target"] = "left"
    elif "右边" in command:
        result["target"] = "right"

    return result


def plan_actions(parsed):
    actions = []

    if parsed["action"] == "pick":
        actions.append(f"移动到{parsed['color']}物体")
        actions.append("抓取物体")

    if parsed["target"]:
        actions.append(f"移动到{parsed['target']}")
        actions.append("放下物体")

    return actions


def execute(actions):
    print("\n🤖 机器人开始执行：")
    for step in actions:
        print("➡️", step)


if __name__ == "__main__":
    command = input("请输入指令：")

    parsed = parse_command(command)
    print("\n🧠 AI解析结果：", parsed)

    actions = plan_actions(parsed)
    print("\n📋 动作规划：", actions)

    execute(actions)
