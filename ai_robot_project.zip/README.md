# AI Robot Natural Language Control Demo

## 运行方法
```bash
python main.py
```

## 示例输入
去拿红色物体然后放到左边

## 项目说明
这是一个简单的AI机器人控制模拟系统：
- 支持自然语言输入
- 自动解析指令
- 转换为机器人动作
